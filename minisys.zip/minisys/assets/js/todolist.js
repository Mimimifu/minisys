 localStorage.setItem("todolist", JSON.stringify([
         {descrition: "Lunch meeting",time:'10:30',turn:1,checked:0},
         {descrition: "Lunch meeting",time:'10:30',turn:1,checked:0},
         {descrition: "Lunch meeting",time:'10:30',turn:1,checked:0},
     {descrition: "Lunch meeting",time:'10:30',turn:1,checked:1},
   
 ]));
    
    let doc_project = document.querySelector('#todolist');
    let storage_todolist = JSON.parse(localStorage.getItem("todolist"));
    
    console.log(storage_todolist);
    
    for(i=0;i<storage_todolist.length;i++){
        doc_project.innerHTML += `<li class="list-group-item">
        <div class="row align-items-center no-gutters">
            <div class="col me-2">
                <h6 class="mb-0"><strong>${storage_todolist[i].descrition}</strong></h6><span class="text-xs">${storage_todolist[i].time} ${(storage_todolist[i].turn == 1? 'AM':'PM')}</span>
            </div>
            <div class="col-auto">
                <div class="form-check"><input id="todolist-${i}" class="form-check-input" type="checkbox"  
        ${(storage_todolist[i].checked == 1 ? 'checked="checked"' :'')} />
                <label class="form-check-label" for="todolist-${i}"></label></div>
            </div>
        </div>
    </li>`;

    }