   

if (document.readyState == 'loading') {


    console.log("carregou profile");
    let imail = document.getElementById('username');    
    let logado = localStorage.getItem('logando');
    let ipassword = document.getElementById('password');
    let irpassword = document.getElementById('repassword');    

    let url = localStorage.getItem('url');     
    imail.setAttribute("value", logado);
    console.log(document.readyState);

    const myElement = document.getElementById('saveprofile');
    myElement.addEventListener("click", function ListenerEvent(e){
       // Remove the listener from the element the first time the listener is run:
       e.preventDefault(); 
       myElement.removeEventListener('click', ListenerEvent); 
        
    if(imail.value == logado && imail.value !== ''){
    console.log('atualizando'); 
    if(ipassword.value == irpassword.value && irpassword.value !== '' && ipassword.value !== ''){
        console.log('...');
        //document.getElementById('infoSucessRegister').style = 'display:block;background: #a4fbc2;';
        localStorage.setItem(imail.value, ipassword.value);
        setTimeout(function(){
            if(imail.value != logado) window.location.href = "login.html";
            window.location.href = "profile.html";
        },2000);
    }else{
        console.log('password not match!');
        //document.getElementById('infoWarningRegisterP').style = 'display:block;background: #f5c2a5;';
        setTimeout(function(){
            window.location.reload();
        },2000);
    }
}else{
    console.log('user not found!');
    //document.getElementById('infoWarningRegisterU').style = 'display:block;background: #f5c2a5;';
    setTimeout(function(){
        window.location.reload();
    },2000);
}
    

    });
    
    /*
    localStorage.setItem("projects", JSON.stringify([
         {project_name: "Server migration",porcentage:100,color:'danger'},
         {project_name:"Sales tracking",porcentage:40,color:'warning'},
         {project_name:"Customer Database",porcentage:60,color:'primary'},
         {project_name:"Payout Details",porcentage:80,color:'info'},
         {project_name:"Account setup",porcentage:100,color:'success'}
    ]));
    */
    let doc_project = document.querySelector('#projectscard');
    let storage_projects = JSON.parse(localStorage.getItem("projects"));
    
    console.log(storage_projects);
    
    for(i=0;i<storage_projects.length;i++){
    doc_project.innerHTML += `<h4 class="small fw-bold">${storage_projects[i].project_name}<span class="float-end">${storage_projects[i].porcentage}%</span></h4><div class="progress progress-sm mb-3">
    <div class="progress-bar bg-${storage_projects[i].color}" aria-valuenow="${storage_projects[i].porcentage}" aria-valuemin="0" aria-valuemax="100" style="width: ${storage_projects[i].porcentage}%;"><span class="visually-hidden">${storage_projects[i].porcentage}%</span></div>
    </div>`;
    }

    
    const modalProjects = document.getElementById('addprojects');
    modalProjects.addEventListener("click", async function ListenerEvent(e){
       // Remove the listener from the element the first time the listener is run:
       e.preventDefault(); 
       //myElement.removeEventListener('click', ListenerEvent); 
    
        let modalProjects = document.getElementById("modalprojects");
        
        let resultHTML = await ajaxHTML('modalprojects.html');
        console.log(resultHTML);
        
        console.log(resultHTML.getElementById("modal-createprojects"));
        
        //modalProjects.innerHTML = resultHTML.getElementById("modal-createprojects");
        modalProjects.append(resultHTML.getElementById("modal-createprojects"))
        
    /*       const observer = new MutationObserver(() => {
            console.log("callback that runs when observer is triggered");
        });

        // call `observe()`, passing it the element to observe, and the options object
        observer.observe(document.querySelector("#modal-createprojects"), {
            subtree: true,
            childList: true,
        });
       
        console.log(observer)
                 */
      let modalcreateprojectsrow0 = document.querySelectorAll("body #modal-createprojects .row")[0];
      modalcreateprojectsrow0.setAttribute("style","display:none");
      let modalcreateprojectsbtnremove = document.querySelector("body #modal-createprojects .btn-danger.remove"); modalcreateprojectsbtnremove.setAttribute("style","display:none"); 
        
      let modalcreateprojectsc1 = document.querySelector("body #modal-createprojects .btn-light");
        
        modalcreateprojectsc1.addEventListener("click", function ListenerEvent(e){
            modalcreateprojectsc1.removeEventListener('click', ListenerEvent);
            modalcreateprojectsc1.setAttribute('style','none');
            modalProjects.innerHTML = '';
        })
        
        let modalcreateprojectsc2 = document.querySelector("body #modal-createprojects .btn-close");

        modalcreateprojectsc2.addEventListener("click", function ListenerEvent(e){
            modalcreateprojectsc2.removeEventListener('click', ListenerEvent);
            modalcreateprojectsc2.setAttribute('style','none');
            modalProjects.innerHTML = '';
        })        

        let modalcreateprojectsc3 = document.querySelector("body #modal-createprojects .btn-primary");

        modalcreateprojectsc3.addEventListener("click", function ListenerEvent(e){
            modalcreateprojectsc3.removeEventListener('click', ListenerEvent);
            let description = document.querySelector("#modal-createprojects [name=description]").value;
            let color = document.querySelector("#modal-createprojects [name=color]").value;
            let porcentage = document.querySelector("#modal-createprojects [name=porcentage]").value;
            let pjt = JSON.parse(localStorage.getItem("projects"));
            console.log(pjt.push({project_name: `${description}`,porcentage: parseInt(`${porcentage}`),color:`${color}`}));
            console.log(pjt)
            localStorage.setItem("projects", JSON.stringify(pjt));
            modalcreateprojectsc3.setAttribute('style','none');
            modalProjects.innerHTML = '';
            window.location.reload();
        })            
        
 
        
    })
       
    const modalProjectsRemove = document.getElementById('removeprojects');
    modalProjectsRemove.addEventListener("click", async function ListenerEvent(e){
       // Remove the listener from the element the first time the listener is run:
       e.preventDefault(); 
       //myElement.removeEventListener('click', ListenerEvent); 
    
        let modalProjects = document.getElementById("modalprojects");
        
        let resultHTML = await ajaxHTML('modalprojects.html');
        console.log(resultHTML);
        
        console.log(resultHTML.getElementById("modal-createprojects"));
        
        //modalProjects.innerHTML = resultHTML.getElementById("modal-createprojects");
        modalProjects.append(resultHTML.getElementById("modal-createprojects"))
    
        let description = document.querySelector("#modal-createprojects [name=description]");
        let color = document.querySelector("#modal-createprojects [name=color]");
        let porcentage = document.querySelector("#modal-createprojects [name=porcentage]");
        let savebtn = document.querySelector("#modal-createprojects .btn-primary");
        description.setAttribute('disabled','disabled');
        color.setAttribute('disabled','disabled');
        porcentage.setAttribute('disabled','disabled');
        savebtn.setAttribute('style','display:none');
        let modalcreateprojectsc1 = document.querySelector("body #modal-createprojects .btn-light");
        
        modalcreateprojectsc1.addEventListener("click", function ListenerEvent(e){
            modalcreateprojectsc1.removeEventListener('click', ListenerEvent);
            modalcreateprojectsc1.setAttribute('style','none');
            modalProjects.innerHTML = '';
        })
        
        let modalcreateprojectsc2 = document.querySelector("body #modal-createprojects .btn-close");

        modalcreateprojectsc2.addEventListener("click", function ListenerEvent(e){
            modalcreateprojectsc2.removeEventListener('click', ListenerEvent);
            modalcreateprojectsc2.setAttribute('style','none');
            modalProjects.innerHTML = '';
        })        
        
        let modalremoveprojects = document.querySelector("body #modal-createprojects .btn-danger .remove");
        
        modalremoveprojects.addEventListener("click", function ListenerEvent(e){
            modalremoveprojects.removeEventListener('click', ListenerEvent);
            let listp = document.querySelector("#modal-createprojects [name=listprojects]").value;
     
            let pjt = JSON.parse(localStorage.getItem("projects"));
       
            
            console.log(pjt.push({project_name: `${description}`,porcentage: parseInt(`${porcentage}`),color:`${color}`}));
            console.log(pjt)
            localStorage.setItem("projects", JSON.stringify(pjt));
            modalcreateprojectsc4.setAttribute('style','none');
            modalProjects.innerHTML = '';
            window.location.reload();
        })         
        
        
        
        
        
        
        
    })
    /* 
    
    var unix = Math.round(+new Date()/1000);
    

    */
    
}

