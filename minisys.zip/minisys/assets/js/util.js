
// Reference https://stackoverflow.com/questions/36631762/returning-html-with-fetch
function ajaxHTML(url,params = {}){
   return fetch(url,params).then(response => response.text().then(
    html => { 
    // Initialize the DOM parser
    const parser = new DOMParser()
    // Parse the text
    const doc = parser.parseFromString(html, "text/html")
    
    return doc;
    }
   )
  )
}
function ajaxJSON(url,params = {}){
   return fetch(url,params).then(response => response.json().then(resolve => resolve))
}

 
