
(function() {
"use strict"; // Start of use strict  
    

localStorage.setItem("url", "http://127.0.0.1:8000");



const myElement = document.getElementById('submitlogin');

myElement.addEventListener('click', function namedListener() {
  // Remove the listener from the element the first time the listener is run:
  myElement.removeEventListener('click', namedListener);

let ilogon = document.getElementById('InputEmail');
let ipassword = document.getElementById('InputPassword');
let login = localStorage.getItem(ilogon.value);
let url = localStorage.getItem('url');    
    
console.log(ilogon.value);   
console.log(login);   
    
if(login != null){
    console.log('logando');
    if(ipassword.value == login){
        console.log('...');
        localStorage.setItem("logando", ilogon.value);
        document.getElementById('infoSucessLogin').style = 'display:block;background: #a4fbc2;';
        setTimeout(function(){
            //window.location.assign("http://google.com");
            //window.location.replace("http://google.com");
            window.location.href = "index.html";
        },2000);
    }else{
        console.log('password not found!');
        document.getElementById('infoWarningLogin').style = 'display:block;background: #f5c2a5;';
        setTimeout(function(){
            window.location.reload();
        },2000);
    }
}else{
    console.log('user not found!');
    document.getElementById('infoWarningLogin').style = 'display:block;background: #f5c2a5;';
    setTimeout(function(){
        window.location.reload();
    },2000);
}
    
  // ...do the rest of your stuff
});

    
})(); // End of use strict