
(function() {
"use strict"; // Start of use strict  
    

localStorage.setItem("url", "http://127.0.0.1:8000");



const myElement = document.getElementById('btnRegister');

myElement.addEventListener('click', function namedListener() {
  // Remove the listener from the element the first time the listener is run:
  myElement.removeEventListener('click', namedListener);

let imail = document.getElementById('InputEmail');
let ipassword = document.getElementById('PasswordInput');
let irpassword = document.getElementById('RepeatPasswordInput');    
let login = localStorage.getItem(imail.value);
let url = localStorage.getItem('url');    


    
if(imail.value != login && imail.value !== ''){
    console.log('registando');
    if(ipassword.value == irpassword.value && irpassword.value !== '' && ipassword.value !== ''){
        console.log('...');
        document.getElementById('infoSucessRegister').style = 'display:block;background: #a4fbc2;';
        localStorage.setItem(imail.value, ipassword.value);
        setTimeout(function(){
            window.location.href = "login.html";
        },2000);
    }else{
        console.log('password not match!');
        document.getElementById('infoWarningRegisterP').style = 'display:block;background: #f5c2a5;';
        setTimeout(function(){
            window.location.reload();
        },2000);
    }
}else{
    console.log('user not found!');
    document.getElementById('infoWarningRegisterU').style = 'display:block;background: #f5c2a5;';
    setTimeout(function(){
        window.location.reload();
    },2000);
}
    
  // ...do the rest of your stuff
});

    
})(); // End of use strict